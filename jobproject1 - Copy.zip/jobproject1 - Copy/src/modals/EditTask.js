import React, { useState , useEffect} from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const EditTask = ({modal, toggle, updateTask, taskObj}) => {
    const [taskName, setTaskName] = useState('');
    const [skills,setSkills]=useState('');
    const [salary,setSalary]=useState('');
    const [work,setWork]=useState('');
    const [description, setDescription] = useState('');

    const handleChange = (e) => {
        
        const {name, value} = e.target

        if(name === "taskName"){
            setTaskName(value)
        }
        if(name==="skills"){
            setSkills(value)
        }
        if(name==="salary"){
            setSalary(value)
        }
        if(name==="work"){
            setWork(value)
        }


    }

    useEffect(() => {
        setTaskName(taskObj.Name)
        setSkills(taskObj.Skills)
        setSalary(taskObj.Salary)
        setWork(taskObj.Work)

        setDescription(taskObj.Description)
    },[])

    const handleUpdate = (e) => {
        e.preventDefault();
        let tempObj = {}
        tempObj['Name'] = taskName
        tempObj["Skills"]=skills
        tempObj["Salary"]=salary
        tempObj["Work"]=work
        tempObj['Description'] = description
        updateTask(tempObj)
    }

    return (
        <Modal isOpen={modal} toggle={toggle}>
            <ModalHeader toggle={toggle}>Update jobs</ModalHeader>
            <ModalBody>
            
            <div className="form-group">
            <label>Job Title</label>
            <input type="text" className="form-control" value={taskName} onChange={handleChange} name="taskName"/>
            </div>

            <div className="form-group">
            <label>Skills</label>
            <input type="text" className="form-control" value={skills} onChange={handleChange} name="skills"/>
            </div>

            <div className="form-group">
            <label>Salary</label>
            <input type="text" className="form-control" value={salary} onChange={handleChange} name="salary"/>
            </div>

            <div className="form-group">
            <label>Work</label>
            <input type="text" className="form-control" value={work} onChange={handleChange} name="work"/>
            </div>

            <div className="form-group">
            <label>Description</label>
            <input type="text" className="form-control" value={description} onChange={handleChange} name="description"/>
            </div>
                
            </ModalBody>
            <ModalFooter>
            <Button color="primary" onClick={handleUpdate}>Update</Button>{' '}
            <Button color="secondary" onClick={toggle}>Cancel</Button>
            </ModalFooter>
      </Modal>
    );
};

export default EditTask;