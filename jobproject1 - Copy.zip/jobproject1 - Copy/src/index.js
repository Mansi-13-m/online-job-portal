import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import TodoList from './components/TodoList';
import About from './About';
import Contact from './Contact';
import Login from './Login';



ReactDOM.render(
   <Router>
   <Routes>
        <Route path='/' element={<App/>}/>
        <Route path='/jobs' element={<TodoList/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/login' element={<Login/>}/>

        





   </Routes>
   </Router>,
   document.getElementById("root")

);