import logo from './logo.svg';
import './App.css';
import TodoList from './components/TodoList'
import 'bootstrap/dist/css/bootstrap.min.css'
//import 'font-awesome/css/font-awesome.min.css'
import Navbar from './Navbar.js';
function App() {
  return (
    <div className="App">
    <Navbar/>
      <TodoList />
    </div>
  );
}

export default App;