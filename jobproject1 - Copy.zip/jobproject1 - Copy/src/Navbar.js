import React from 'react';
import {Link} from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  return (
    <div className="main"> 
    <div className="sum">
      <div className="logo">
      Job Portal
      </div>
      <nav className='item'>
      <ul className='ul'>
      
     

      <li>
      <Link to='/contact'>Contact</Link>
      </li>
      <li>
      <Link to='/login'>Login</Link>
      </li>
      </ul>

      </nav>
     
    </div>
    <img src="https://cdn.wallpapersafari.com/51/27/78VlbA.jpg"></img>
    </div>
    
  );
}

export default Navbar
